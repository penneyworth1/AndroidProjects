package stevenstewart.programmingtest.nike.Api;

/**
 * Created by stevenstewart on 12/14/14.
 */
public class KeyValuePair
{
    public String key;
    public String value;
    public KeyValuePair(String keyPar, String valuePar)
    {
        key = keyPar;
        value = valuePar;
    }
}
