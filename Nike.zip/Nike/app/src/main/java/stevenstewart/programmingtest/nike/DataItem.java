package stevenstewart.programmingtest.nike;

import java.util.Date;

/**
 * Created by stevenstewart on 12/14/14.
 */
public class DataItem
{
    public int id;
    public double acceleration;
    public double currentEuroValue;
    public String date;

    public DataItem()
    {

    }
}
